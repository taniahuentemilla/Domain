<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \Response;
use App\Http\Requests;
use App\User;


class Registro_usuarioController extends Controller
{
    public function ReadUsuarios(Request $request) {
		if ($request->has('usuario_id')) {
			$usuarios = User::find($request->usuario_id);

			$retorno['error']     = false;
        	$retorno['respuesta'] = $usuarios;
		} else {
			$usuarios = User::all();
			
			$retorno['error']     = false;
        	$retorno['respuesta'] = $usuarios;
		}
		return Response::json($retorno);
	}

	public function CreateUsuarios(Request $request) {
		$usuario = new User();
		$val = $usuario->Validar($request->all());

    	if ($val->fails()) {
    		$retorno['error']     = true;
        	$retorno['respuesta'] = $val->messages();
    	} else {
			$usuario->name 	  	= $request->nombre;
			$usuario->email 	= $request->correo;
			$usuario->password  = $request->password;
			$usuario->save();

			$retorno['error']     = false;
        	$retorno['respuesta'] = $usuario;
		}
		return Response::json($retorno);
	}
}



